import React from 'react';

const Cart = () => {
  return (
    <div>
      <h1>Cart Page</h1>
      <p>This page will contain cart data in Week 4.</p>
    </div>
  );
};

export default Cart;
