   import React, { useState } from 'react';

   const StreamList = () => {
     const [inputValue, setInputValue] = useState('');
     const [streams, setStreams] = useState([]);

     const handleInputChange = (e) => {
       setInputValue(e.target.value);
     };

     const handleSubmit = (e) => {
       e.preventDefault();
       if (inputValue) {
         setStreams([...streams, { id: Date.now(), title: inputValue, completed: false }]);
         setInputValue('');
       }
     };

     const handleDelete = (id) => {
       setStreams(streams.filter(stream => stream.id !== id));
     };

     const handleComplete = (id) => {
       setStreams(streams.map(stream => 
         stream.id === id ? { ...stream, completed: !stream.completed } : stream
       ));
     };

     return (
       <div>
         <h1>StreamList</h1>
         <form onSubmit={handleSubmit}>
           <input
             type="text"
             value={inputValue}
             onChange={handleInputChange}
             placeholder="Add a movie or program"
           />
           <button type="submit">Add</button>
         </form>
         <ul>
           {streams.map(stream => (
             <li key={stream.id} style={{ textDecoration: stream.completed ? 'line-through' : 'none' }}>
               {stream.title}
               <i className="fas fa-check" onClick={() => handleComplete(stream.id)} style={{ cursor: 'pointer', marginLeft: '10px' }} />
               <i className="fas fa-edit" onClick={() => console.log('Edit functionality here')} style={{ cursor: 'pointer', marginLeft: '10px' }} />
               <i className="fas fa-trash" onClick={() => handleDelete(stream.id)} style={{ cursor: 'pointer', marginLeft: '10px' }} />
             </li>
           ))}
         </ul>
       </div>
     );
   };

   export default StreamList;
