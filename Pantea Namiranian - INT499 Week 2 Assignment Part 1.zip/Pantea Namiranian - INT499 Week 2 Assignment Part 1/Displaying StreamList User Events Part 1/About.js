import React from 'react';

const About = () => {
  return (
    <div>
      <h1>About Page</h1>
      <p>This page will contain information in Week 5.</p>
    </div>
  );
};

export default About;
